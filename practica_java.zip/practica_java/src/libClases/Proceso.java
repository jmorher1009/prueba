package libClases;

public interface Proceso {
	public abstract boolean equals(Object obj);	//true si son iguales
	void ver();									//muestra en pantalla el objeto
}
