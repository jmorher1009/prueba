#ifndef PRUE_H
#define PRUE_H

#include <Contrato.h>


class prue : public Contrato
{
    public:
        prue();
        virtual ~prue();

    protected:

    private:
};

#endif // PRUE_H
